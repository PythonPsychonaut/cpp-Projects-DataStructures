// This program prints a simple smiley face.
#include <iostream>
using namespace std;

int main()
{
   cout << "\n\n";
   cout << "     ^   ^  \n";
   cout << "       *    \n";
   cout << "     \\___/  \n";
   return 0;
}
