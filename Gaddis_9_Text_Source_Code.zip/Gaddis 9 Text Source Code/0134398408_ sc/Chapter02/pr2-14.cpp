// This program uses character literals.
#include <iostream>
using namespace std;

int main()
{
   char letter;

   letter = 'A';
   cout << letter << '\n';
	
   letter = 'B';
   cout << letter << '\n';
   return 0;
}
