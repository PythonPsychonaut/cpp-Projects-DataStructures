#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <string>
#include <ctime>
#include <fstream>

using namespace std;
const string TITLE = "\n\n\t\t\tWelcome to the Magicians Guild!\n\n";
const string BOOKING_SUB_TITLE = "\t\t\t       Booking Schedule\n\n";
const string HOLIDAY_SUB_TITLE = "\t\t\t         Holiday List\n\n";
const string MAGICIAN_SUB_TITLE = "\t\t\t        Magician List\n\n";
const string DASHES = "\t\t---------------------------------------------------\n";
const int MAX_HOLIDAYS = 4;
const int MAX_MAGICIANS = 7;
int transCounter = 1000;	// Global transaction counter for transaction file output

class Magician
{
	private:
		bool _available;
		Magician* _nextPtr;
		Magician* _headPtr;

		int _count;
		string _name;
		string _holiday;
		string _customer;
		
	public:		
		Magician();
		Magician(string);
		Magician* findMagician();
		Magician* findMagicianByName(string);
		bool addMagician(string);
		bool getAccessibility();
		bool isEmpty();
		string getName();
		string getHoliday();
		string getCustomer();
		void printMagicians();
		void setHoliday(string);
		void setAccessibility(bool);
		void setCustomer(string);

};
class Booking
{
	private:
		string _holiday;
		string _customer;
		string _magician;
		int _count;
		Booking* _nextPtr;
		Booking* _headPtr;
		bool _booked;
	public:
		Booking();
		Booking(string);
		Booking* findBooking(Booking*, string);
		Booking* findBookingByMagician(Booking*, string);
		Booking* findBookingByMagicianAndCustomer(string, string);
		Booking* addBooking(string, string, string);
		bool isEmpty();
		bool getBooked();
		bool deleteBooking(Magician*, string, string);
		int getCount();
		string getHoliday();
		string getMagician();
		string getCustomer();
		void statusMagician(string);
		void statusHoliday(string);
		void printHolidays(string []);
		void printBookings();
		void setHoliday(string);
		void setCustomer(string);
		void setMagician(string);
};

/*  ---------------------------
	Magician Class Functions   
    --------------------------
	Constructors
	--------------------------
*/
    
Magician::Magician()
{	
		_available = true;
		_nextPtr = nullptr;
		_headPtr = nullptr;

		_count = 0;
		_holiday = "";
		_customer = "";
}
Magician::Magician(string name)
{
	if (!addMagician(name))
		cout << "Add of single item " << name << " failed! " << endl;
}


/* Function addMagician
   Adds a magician node to end the Magicians list
   Input: Magician's name as string
   Output: true or false (did the add work)
*/   
bool Magician::addMagician(string name)
{
	Magician* newNode = new Magician();		// create the new node
	newNode->_name = name;		// set the value of the new node to the passed item
	newNode->_holiday = "NONE";
	newNode->_customer = "NONE";
	newNode->_nextPtr = nullptr;

	if (isEmpty())	// Add firstNode
	{
		_count = 1;	// increment internal counter
		_headPtr = newNode;	// if this is the first node added, initialize _headPtr
	}
	else
	{
		Magician* curPtr = _headPtr;		// Start traversal at first node
		while (curPtr->_nextPtr != nullptr)	// Loop until we get to the last node since we are adding after it
			curPtr = curPtr->_nextPtr;	// go to next node in the list

		//curPtr is now at last node in list
		curPtr->_nextPtr = newNode;		//last node in original list now points at new node
		_count++;	//increment internal counter of list items
	}
	return true;
}
/*  --------------------------------------------------------------------------
	Function findMagician
   	Finds the next available Magician to assign to a holiday.  An available
   	Magician has its _available flag set to true OR if he/she is not
   	available, if the holiday is different than the one being addressed,
   	the Magician can be assigned to it.
   	Input: holiday as string (the holiday to be assigned to)
   	Output: A pointer to an available Magician (or nullptr if none)
   	--------------------------------------------------------------------------
*/
Magician* Magician::findMagician()
{
	Magician* curPtr = _headPtr;  //Start traversal at first node

	while (curPtr != nullptr)
	{
		if (curPtr->_available)
			return curPtr;		// pointer to available magician

		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	return nullptr;	// no one is available
}
/*  ----------------------------------------------------------------
	Function findMagicianByName
   	Finds the node for the passed Magician name.
   	Input: name as string (name of magician being sought)
   	Output: pointer to the Magician if found, nullptr if not found
    ---------------------------------------------------------------
*/
Magician* Magician::findMagicianByName(string name)
{
	Magician* curPtr = _headPtr;  //Start traversal at first node

	while (curPtr != nullptr)
	{
		if (curPtr->_name == name)  // if found return pointer to the node
			return curPtr;  // pointer to the found Magician

		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	return nullptr;		// Magician not found
}
/*	------------------------------------------------------------------
	Function isEmpty()
	Returns the current count of Magician nodes
	Input: None
	Output: private variable _count as int
	------------------------------------------------------------------
*/
bool Magician::isEmpty()
{
	return (_count == 0);
}
/*	-------------------------------------
	Magician list get and set functions
	-------------------------------------
*/
bool Magician::getAccessibility()
{
	return _available;
}
string Magician::getHoliday()
{
	return _holiday;
}
string Magician::getName()
{
	return _name;
}
string Magician::getCustomer()
{
	return _customer;
}
void Magician::setCustomer(string customer)
{
	_customer = customer;
}

void Magician::setHoliday(string holiday)
{
	_holiday = holiday;
}
void Magician::setAccessibility(bool flag)
{
	_available = flag;
}
void Magician::printMagicians()
{
	Magician* curPtr = _headPtr;
	cout << left << setw(17) << "\n\nMagician Name" << right << setw(22) << "Customer" << setw(20) << "Holiday Booked" << setw(15) << "Available?" << boolalpha << endl;
	cout << "---------------------------------------------------------------------------\n";
	while(curPtr != nullptr)
	{
		cout << left << setw(17) << curPtr->getName() << right << setw(17) << curPtr->getCustomer() << setw(20)
		     << curPtr->getHoliday() << setw(15)<< curPtr->getAccessibility() << endl;
		curPtr = curPtr->_nextPtr;
	}
}
/*------ END OF MAGICIAN CLASS FUNCTIONS --------*/

/*  ---------------------------
	Holiday Class Functions   
    ---------------------------
	Constructor
	---------------------------
*/
Booking::Booking()
{
	_count = 0;		// Initialize internal counter
	_nextPtr = nullptr;	
}
/*	----------------------------------------------------------------------
	Function addBooking
	Adds a new booking to the Holiday list in customer name order.
	Input: holiday as string, customer as string, magician name as string,
		   pointer to Magician list
	Output: Did it work (true or false)
	----------------------------------------------------------------------
*/
Booking* Booking::addBooking(string holiday, string customer, string magician)
{
	Booking* newNode = new Booking();		// create the new node
	newNode->_nextPtr = nullptr;			// new node's next member is nullptr
	newNode->_holiday = holiday;		// set the value of the new node to the passed item
	newNode->_booked = true;	// Holiday is booked for this customer
	newNode->_customer = customer;	// set the value of the customer (key)
	newNode->_magician = magician;	// set the value of the magician
	
	/* 	If the list is empty it becomes the only node (first if is true)
	    If not empty, determine where the new node will go by finding first node 
		where customer name is alphabetically greater than the passed name, then  
		   1.  If the list is not empty
		       a. Find the spot to place new node
		       b. If there is only one node in the list we have to insert before it (if prevPtr == nullptr)
		       c. prevPtr points to node before new node (update its _nextptr variable)
		          curPtr points to node after the new node (update new node _nextPtr to curPtr)
	*/
	if (isEmpty())
	{
		_count = 1;	// increment internal counter
		_headPtr = newNode;	// if this is the first node added, initialize _headPtr
		newNode->_nextPtr = nullptr;	// only one node: points to nothing
	}
	else
	{
		Booking* curPtr = _headPtr;		// Start traversal at first node
		Booking* prevPtr = nullptr;
		

		while (curPtr != nullptr && curPtr->getCustomer() < customer)	
		{
			prevPtr = curPtr;		// save ptr to current node as a previous node
			curPtr = curPtr->_nextPtr;	// go to next node in the list
		}
		if (prevPtr == nullptr)		// There is only one node so we have to insert before it in the list
		{
			_headPtr = newNode;		// headptr now points at the new node
			newNode->_nextPtr = curPtr;	// new node now points at the previously lonely node in the list
		}
		else		// insert between two other nodes
		{
			prevPtr->_nextPtr = newNode;	// make previoous node point to the new one
			newNode->_nextPtr = curPtr;		// make new node point to the node we found whose customer name was greater than input name
		}
		
		_count++;	//increment internal counter of list items
	}
		
	return newNode;
}
/*	----------------------------------------------------------------------
	Function deleteBooking
	Deletes a booking from the Holiday list by matching a customer
	name and holiday name.
	Input: pointer to the Magician list, customer as string, holiday name as string,
	Output: NONE
	----------------------------------------------------------------------
*/
bool Booking::deleteBooking(Magician* list, string customer, string holiday)
{
	Booking* curPtr;
	Booking* prevPtr;
	
	if(!_headPtr)
		return false;  // Nothing in the list
	
	// first node matches, we use _headPtr to delete it
	if (_headPtr->getCustomer() == customer && _headPtr->getHoliday() == holiday)
	{
		Magician* employee = list->findMagicianByName(_headPtr->_magician);
		if (employee)
		{
			employee->setAccessibility(true);
			employee->setCustomer("NONE");
			employee->setHoliday("NONE");
		}
		curPtr = _headPtr->_nextPtr;	// could be nullptr if only one node
		delete _headPtr;
		_headPtr = curPtr;
		_count--;
	}
	else
	{
		curPtr = _headPtr;	// Start at first item in list 
		// Look for a matching customer name and holiday name
		while(curPtr != nullptr && curPtr->getCustomer() != customer && curPtr->getHoliday() != holiday)
		{
			prevPtr = curPtr;
			curPtr = curPtr->_nextPtr;
		}
		if (curPtr)	// found a match to delete, if !curPtr we reached the end of the list without finding one to delete
		{
			// Reset Magician data, this magician is now available
			Magician* employee = list->findMagicianByName(curPtr->_magician);
			if (employee)
			{
				employee->setAccessibility(true);
				employee->setCustomer("NONE");
				employee->setHoliday("NONE");
			}
			prevPtr->_nextPtr = curPtr->_nextPtr;	// reset pointers
			delete prevPtr;		// delete matching node
			_count--;
		}
		else
			return false;
	}
	return true;
}
/*	--------------------------------------------------------------
	Function findHoliday
	Finds the passed holiday in the bookings list - used for 
	printing the status of the bookings for the passed holiday.
	Inputs: pointer to the bookings list
				starts with _headPtr
				current could hold the next position to search
					when looking for more bookings for this
					holiday
			holiday as string
	Outputs: pointer to the next matching booking node or nullptr
	---------------------------------------------------------------
*/
Booking* Booking::findBooking(Booking* current, string holiday)
{
	Booking* curPtr;	// Define a poiner to a Holiday object
	if (current == nullptr)
		curPtr = _headPtr;  //Start traversal at first node
	else 
		curPtr = current->_nextPtr;	// Start at the next node after the passed node (search for more hits)

	while (curPtr != nullptr)
	{
		if (curPtr->_holiday == holiday)  
			return curPtr;		// pointer to a matching booking node

		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	return nullptr;	// no matching booking node found
}
/*	-------------------------------------------------------------
	Function findHolidayByMagician
	Finds the passed Magician in the bookings list - used for
	printing the status of the bookings for the passed Magician.
	Inputs: pointer to the bookings list
				starts with _headPtr
				current could hold the next position to search
					when looking for more bookings for this
					Magician
			magician as string
	Outputs: pointer to the next matching booking node or nullptr
	---------------------------------------------------------------
*/
Booking* Booking::findBookingByMagician(Booking* current, string magician)
{
	Booking* curPtr;	// Define a pointer to a Holiday object
	if (current == nullptr)
		curPtr = _headPtr;  //Start traversal at first node
	else 
		curPtr = current->_nextPtr;		// Start at the next node after the passed node (search for more hits)

	while (curPtr != nullptr)
	{
		if (curPtr->_magician == magician)  
			return curPtr;		// pointer to a matching booking node

		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	return nullptr;	// no matching booking node found
}
Booking* Booking::findBookingByMagicianAndCustomer(string magician, string customer)
{
	Booking* curPtr;	// Define a pointer to a Holiday object

	curPtr = _headPtr;  //Start traversal at first node

	while (curPtr != nullptr)
	{
		if (curPtr->_magician == magician && curPtr->_customer == customer)  
			return curPtr;		// pointer to a matching booking node

		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	return nullptr;	// no matching booking node found
}
bool Booking::isEmpty()
{
	return (_count == 0);
}
/*	-------------------------------------
	Holiday list get and set functions
	-------------------------------------
*/
int Booking::getCount()
{
	return _count;
}
string Booking::getMagician()
{
	return _magician;
}
bool Booking::getBooked()
{
	return _booked;
}

string Booking::getCustomer()
{
	return _customer;
}
void Booking::setCustomer(string customer)
{
	_customer = customer;
}
void Booking::setMagician(string magician)
{
	_magician = magician;
}

/*	--------------------------------------------------------------
	Function printBookings()
	Prints a list of all bookings (in customer name order.
	Inputs: None
	Outputs: None
	--------------------------------------------------------------
*/
void Booking::printBookings()
{
	Booking* curPtr = _headPtr;  //Start traversal at first node
	cout << TITLE << BOOKING_SUB_TITLE;
	
	cout << setw(15) << "\t\tHoliday" << setw(10) << "       " << setw(20) << "Customer" << setw(20) << "Magician" << endl;
	cout << DASHES;
	while (curPtr != nullptr)
	{
		cout << boolalpha << "\t\t" << setw(15) << curPtr->getHoliday();
		if (curPtr->_booked == true)
			cout << setw(8) << "    ";
		else
			cout << setw(8) << "    ";
	
		cout << setw(20) << curPtr->getCustomer() << setw(20) << curPtr->getMagician() << endl;
			
		curPtr = curPtr->_nextPtr;		// go to next node in the list
	}
	cout << endl << endl;
}
void Booking::printHolidays(string array[])
{
	system("cls");
	cout << TITLE << HOLIDAY_SUB_TITLE;
	for (int i=0; i < MAX_HOLIDAYS; i++)
		cout << "\t" << setw(20) << array[i] << endl;
	cout << endl << endl;
}
/*	***********************************************************
	Function statusMagician
	Displays a report of bookings for the passed magician name.
	Inputs: Bookng list as pointer (list)
			Magician name as string (magician)
	Ouptut: NONE
	***********************************************************
*/
void Booking::statusMagician(string magician)
{
	Booking* event = findBookingByMagician(nullptr, magician);  // Find first booking for the magician parameter
	
	if (event == nullptr)	// No bookings found for magician parameter
		cout << "\tThis magician has not been booked!" << endl;
	else
	{
		system("cls");
		cout << TITLE << MAGICIAN_SUB_TITLE;
		cout << setw(15) << "\t\tName" << setw(20) << "Holiday Booked" << endl;
		cout << DASHES;
		// Output the booking information and then loop for the next booking for this magician
		do
		{
			cout << boolalpha << "\t\t" << setw(15) << magician;
			cout << setw(14) << event->_holiday << endl;
			event = findBookingByMagician(event, magician);
		} while (event != nullptr);	// end of list reached
	}
	cout << endl << endl;
}
/*	***********************************************************
	Function statusHoliday
	Displays a report of bookings for the passed holiday name.
	Inputs: Bookng list as pointer (list)
			Holiday name as string (holiday)
	Ouptut: NONE
	***********************************************************
*/
void Booking::statusHoliday(string holiday)
{
	// find first booking for the holiday parameter
	Booking* event = findBooking(nullptr, holiday);	
	
	if (event == nullptr)	// No bokkings for holiday parameter
		cout << "\t\aThis holiday has no bookings!" << endl;	
	else
	{
		system("cls");
		cout << TITLE << BOOKING_SUB_TITLE;
		cout << setw(15) << "\t\tHoliday" << "\t\tCustomer" << setw(20) << "\t   Magician" << endl;
		cout << DASHES << boolalpha;
		// Output the booking information and then loop for the next booking for this holiday
		do
		{
			cout << "\t\t" << setw(15) << event->getHoliday() << setw(8) << "    ";
			cout << setw(20) << event->getCustomer() << setw(20) << event->getMagician() << endl;
			
			event = findBooking(event, holiday);  // save pointer to current node
		} while (event != nullptr);	// reached the end of the list
		
		cout << endl << endl;	
	}
}

string Booking::getHoliday()
{
	return _holiday;
}

/*  ----------------------
	Main Driver Procedure 
	----------------------*/
int main()
{
	// Main function prototypes
	int getMenuItem();
	bool validHoliday(string, string[]);
	void clear();
	void pause();
	
	// Main variables
	string customerChoice, holidayChoice, magicianChoice;
	int response;
	
	// file services
	ofstream transFile;	// output file for transactions
	fstream magicianNames;  // input file for magician names
	transFile.open("Magic.trn", ios::out);	// transaction file
	magicianNames.open("MagicianNames.txt",ios::in);	// list of magicians
	
	if(!magicianNames)
		cout << "\n\t\aError opening magician file" << endl;
	
	// List of holidays (for printing)
	string holidays[MAX_HOLIDAYS] = {"New Years", "Valentines Day", "July 4th" ,"Labor Day"};
	
	// Store magician names for printing
	string magicians[MAX_MAGICIANS];

	// Create a list of Magicians
	Magician* nodes = new Magician();

	// Build Magician list form external text file
	int magicianCount = 0;
	while(getline(magicianNames, magicianChoice))
	{	
		nodes->addMagician(magicianChoice);		// Add a magician node to the list
		magicians[magicianCount++] = magicianChoice;	// Add name to the magicians array
	}
	magicianNames.close();
	
	Booking* days = new Booking();	// Create a new Holiday Bookings list

	response = getMenuItem();	// Display menu and get user's choice
	
	while(response != 9)		// 9 = QUIT
	{
		if(response == 1)	// 1 = Book a magician
		{
			clear();
			days->printHolidays(holidays);	// display the holidays for input (from internal array)
			cout << "\n\tEnter the name of the customer ";
			getline(cin, customerChoice);
		
			cout << "\n\tEnter the holiday to book: ";
			getline(cin, holidayChoice);
			
			// Validate holiday entered
			while (!validHoliday(holidayChoice, holidays))
			{
				cout << "\n\t\aIncorrect Holiday.  Enter the holiday to book: ";
				getline(cin, holidayChoice);
			}
			
			Magician* employee = nodes->findMagician();  // Find the next available Magician
			transCounter++;		// Update transaction counter and output transaction heading
			transFile << setw(4) << transCounter << " Booking" << endl;

 			if (!employee)	// didn't find any available
			{
				cout << "\n\a\tAll magicians are booked! Try again at a later date." << endl;
				transFile << "\t\tAll magicians are booked! Try again at a later date." << endl;
			}
			else
			{
				// report status of transaction
				transFile << "\t\tCustomer is " << customerChoice << endl;
				transFile << "\t\tHoliday is " << holidayChoice << endl;
				transFile << "\t\tAssigned Magician is " << employee->getName() << endl;
				
				cout << "\t" << employee->getName() << " is available and will be booked!" << endl << endl << endl;
				transFile << "\t\t" << employee->getName() << " is available and will be booked for " << holidayChoice << endl;
				
				// Add the booking to the list
				Booking* event = days->addBooking(holidayChoice, customerChoice, employee->getName());
				if (!event)
				{
					cout << "\n\a\tError adding booking for " << customerChoice << " - " << employee->getName() << endl;
					transFile << "\t\tError adding booking for " << customerChoice << " - " << employee->getName() << endl;
				}
				else
				{
					// Update Magician information
					employee->setHoliday(holidayChoice);
					employee->setAccessibility(false);
					employee->setCustomer(customerChoice);
					cout << "\tSuccessfully booked " << employee->getName() << " for customer " << customerChoice << endl;
					transFile << "\t\tSuccessfully booked " << employee->getName()
							  << " on " << holidayChoice << " for customer " << customerChoice << endl;
				}
				transFile << "\t\t***** END OF TRANSACTION " << transCounter << " *****" << endl;
			}
		}
		else if (response == 2)	// 2 = Display all bookings
		{
			if (days->getCount() <= 0)
				cout << "\n\n\t\aThe bookings list is empty! Try another option!" << endl << endl << endl;
			else
			{
				clear();
				days->printBookings();
			}
		}
		else if (response == 3)	// 3 = Replace a magician with the next available
		{
			transCounter++;
			transFile << setw(4) << transCounter << " Replace" << endl;
			Booking* event = nullptr;
			do
			{
				cout << "\tEnter the name of the Magician to replace (or type quit): ";
				getline(cin, magicianChoice);
				if (magicianChoice == "quit" || magicianChoice == "QUIT")
					break;
				transFile << "\t\tAttempting to replace Magician " << magicianChoice << endl;

				cout << "\tEnter the name of the Customer affected (or type quit): ";
				getline(cin, customerChoice);
				if (customerChoice == "quit" || customerChoice == "QUIT")
					break;
				transFile << "\t\tAttempting to replace Magician for customer " << customerChoice << endl;
				event = days->findBookingByMagicianAndCustomer(magicianChoice, customerChoice);
			} while (event == nullptr);		// maybe the user misspelled the name?
			
			if (event)
			{
				Magician* newMagician = nodes->findMagician();		// find next available
				Magician* magicianBeingReplaced = nodes->findMagicianByName(magicianChoice);  // Find the booking item to change

				if (newMagician)	// found an available magician
				{
					transFile << "\t\tNext available Magician is " << newMagician->getName() << endl;
					newMagician->setHoliday(event->getHoliday());		// book the new magician
					newMagician->setAccessibility(false);	// new magician not available now
					newMagician->setCustomer(customerChoice); 
					event->setMagician(newMagician->getName() );	// update the event record with new magician
					
					// reset replaced magician's data members
					magicianBeingReplaced->setCustomer("NONE");
					magicianBeingReplaced->setAccessibility(true);
					magicianBeingReplaced->setHoliday("NONE");
					
					// report status of transaction
					cout << "\n\tReplaced " << magicianChoice << " with " << newMagician->getName() 
					     << " for the " << event->getHoliday() << " holiday!" << endl;
					transFile << "\t\tReplaced " << magicianChoice << " with " << newMagician->getName() 
					     << " for the " << event->getHoliday() << " holiday!" << endl;
					transFile << "\t\t***** END OF TRANSACTION " << transCounter << " *****" << endl;
				}
				else
				{
					cout << "\a\n\tAll magicians are booked! " << magicianChoice << " cannot be replaced right now!" << endl;	
					transFile << "\t\tAll magicians are booked! " << magicianChoice << " cannot be replaced right now!" << endl;
					transFile << "\t\t***** END OF TRANSACTION " << transCounter << " *****" << endl;	
				}
			}
			else
			{
				cout << "\n\t\aNo matching booking found for replacement! Try again!" << endl;
				transFile << "\t\tNo matching booking found for repalcement!" << endl;
				transFile << "\t\t***** END OF TRANSACTION " << transCounter << " *****" << endl;
			}
		}
		else if (response == 4)		// 4 = List bookings for an input Magician
		{
			if (days->getCount() > 0)
			{
				cout << "\tEnter Magician: ";
				getline(cin, magicianChoice);
				days->statusMagician(magicianChoice);	// function to display bookings for magician entered
			}
			else
				cout << "\n\n\t\aThe bookings list is empty! Try another option!" << endl << endl << endl;
		}
		else if (response == 5)  // 5 = List bookings for an input Holiday
		{
			if (days->getCount() > 0)
			{
				cout << "\tEnter Holiday: ";
				getline(cin, holidayChoice);
				
				// Validate holiday entered
				while (!validHoliday(holidayChoice, holidays))
				{
					cout << "\n\t\aIncorrect Holiday.  Enter the holiday to book: ";
					getline(cin, holidayChoice);
				}
				days->statusHoliday(holidayChoice);	// function to display bookings for holiday entered
			}
			else
				cout << "\n\n\t\aThe bookings list is empty! Try another option!" << endl << endl << endl;
		}
		else if (response == 6)	// 6 = delete a booking
		{
			if (days->getCount() > 0)
			{
				transCounter++;
				transFile << setw(4) << transCounter << " Deleting" << endl;
				cout << "\tEnter Customer Name: ";
				getline(cin, customerChoice);
				cout << "\tEnter Holiday: ";
				getline(cin, holidayChoice);
				
				// Validate holiday entered
				while(!validHoliday(holidayChoice, holidays))
				{
					cout << "\n\t\aIncorrect Holiday. Enter Holiday: ";
					getline(cin, holidayChoice);
				}
				bool result = days->deleteBooking(nodes, customerChoice, holidayChoice);	// delete the booking
				// report status of transaction
				if (result)
				{
					cout << "\n\tBooking for customer " << customerChoice << " for holiday " << holidayChoice << " was deleted! " << endl;
					transFile << "\t\tBooking for customer " << customerChoice << " for holiday " << holidayChoice << " was deleted! " << endl;
				}
				else
				{
					cout << "\n\t\aDelete booking for customer " << customerChoice << " for holiday " << holidayChoice << " FAILED! " << endl;
					transFile << "\t\tDelete booking for customer " << customerChoice << " for holiday " << holidayChoice << " FAILED! " << endl;
				}
				transFile << "\t\t***** END OF TRANSACTION " << transCounter << " *****" << endl;
			}
			else
				cout << "\n\n\t\aThe bookings list is empty! Try another option!" << endl << endl << endl;
		}
		else if (response == 7)	// 7 = Simple print of magician list
		{
			clear();
			nodes->printMagicians();
		}
		pause();
		clear();
		response = getMenuItem();	// User choice
	}

	
	transFile.close();		// close transaction file
	delete nodes;		// delete dynamic memory for Magician list
	nodes = nullptr;
	delete days;		// delete dynamic memory for Holiday Bookings list
	days = nullptr;
}
	


/* Utility Functions  */
/*	***********************************************
	Function getMenuItem
	Displays a menu and inputs the user's choice.
	Inputs: NONE
	Outputs: Menu choice as int (item)
	************************************************
*/
int getMenuItem()
{
	int item;
	cout << endl << endl << left;
	cout << TITLE;
	cout << setw(30) << "\t1. Book a Magician" << endl;
	cout << setw(30) << "\t2. Status of all Bookings" << endl;
	cout << setw(30) << "\t3. Replace a Magician" << endl;
	cout << setw(30) << "\t4. Status of a Magician" << endl;
	cout << setw(30) << "\t5. Status of a Holiday" << endl;
	cout << setw(30) << "\t6. Delete Booking by Customer and Holiday" << endl;
	cout << setw(30) << "\t7. List of Magicians" << endl;
	cout << setw(30) << "\t9. Quit" << endl;
	cout << setw(30) << "\tEnter desired option: ";
	
	cin >> item;
	cin.ignore();
	
	return item;	// return selection
}
void pause()
{
	system("pause");
}
void clear()
{
	system("cls");
}

/***********************************************************
	Function validHoliday
	Searches for the passed holiday name in the holidays
	array and returns true if found, false if not.
	Inputs: holiday name as string (event)
	        holidays array as string (array)
	Outputs: true or false
 *********************************************************/
bool validHoliday(string event, string array[])
{
	for (int counter=0; counter < MAX_HOLIDAYS; counter++)
	{
		if (event == array[counter])
			return true;	// found holiday return true

	}
	return false;	// holiday not found return false
}
