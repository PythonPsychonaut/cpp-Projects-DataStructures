#include <iostream>
using namespace std;int main(){double shares=220.0;double 
avgPrice=14.67;cout
<<"There were "<<shares<<" shares sold at $"<<avgPrice<<
" per share.\n"; return 0;}
