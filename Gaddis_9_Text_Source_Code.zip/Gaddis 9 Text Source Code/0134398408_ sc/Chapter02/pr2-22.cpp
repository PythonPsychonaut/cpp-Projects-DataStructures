 /*
    PROGRAM: Payroll.cpp
    Written by Herbert Dorfmann
    This program calculates company payroll
    Last modified: 8/20/2012
 */
  #include <iostream>
  using namespace std;
 
  int main()
  {
     int employeeID;   // Employee ID number 
     double payRate;   // Employees hourly pay rate
     double hours;     // Hours employee worked this week     

    (The remainder of this program is left out.)
