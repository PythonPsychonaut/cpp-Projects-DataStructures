#include "NumberList.h"
class SortedNumberList : public NumberList  
{
public:
    void add(double number);    
};


