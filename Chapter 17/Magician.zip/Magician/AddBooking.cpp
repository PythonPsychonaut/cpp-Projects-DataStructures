bool Holiday::addBooking(string holiday, string customer, string magician, Magician* list)
{
	Holiday* newNode = new Holiday();		// create the new node
	newNode->_nextPtr = nullptr;			// new node's next member is nullptr
	newNode->_holiday = holiday;		// set the value of the new node to the passed item
	newNode->_booked = true;	// Holiday is booked for this customer
	newNode->_customer = customer;	// set the value of the customer (key)
	newNode->_magician = magician;	// set the value of the magician
	
	/* 	If the list is empty it becomes the only node (first if is true)
	    If not empty, determine where the new node will go by finding first node 
		where customer name is alphabetically greater than the passed name, then  
		   1.  If the list is not empty
		       a. Find the spot to place new node
		       b. If there is only one node in the list we have to insert before it (if prevPtr == nullptr)
		       c. prevPtr points to node before new node (update its _nextptr variable)
		          curPtr points to node after the new node (update new node _nextPtr to curPtr)
	*/
	if (isEmpty())
	{
		_count = 1;	// increment internal counter
		_headPtr = newNode;	// if this is the first node added, initialize _headPtr
		newNode->_nextPtr = nullptr;	// only one node: points to nothing
	}
	else
	{
		Holiday* curPtr = _headPtr;		// Start traversal at first node
		Holiday* prevPtr = nullptr;
		
		// Find position to insert node
		while (curPtr != nullptr && curPtr->getCustomer() < customer)	
		{
			prevPtr = curPtr;		// save ptr to current node as a previous node
			curPtr = curPtr->_nextPtr;	// go to next node in the list
		}
		if (prevPtr == nullptr)		// There is only one node so we have to insert before it in the list
		{
			_headPtr = newNode;		// headptr now points at the new node
			newNode->_nextPtr = curPtr;	// new node now points at the previously lonely node in the list
		}
		else		// insert between two other nodes
		{
			prevPtr->_nextPtr = newNode;	// make previoous node point to the new one
			newNode->_nextPtr = curPtr;		// make new node point to the node we found whose customer name was greater than input name
		}
		
		_count++;	//increment internal counter of list items
	}
	
	// Update corresponding Magician node
	Magician* performer = list->findMagicianByName(magician);	// finds Magician in the Magician list to update its data
	if (performer)
	{
		performer->setCustomer(customer);		// set customer name
		performer->setHoliday(holiday);			// set holiday name
		performer->setAccessibility(false);		// not available for this holiday again
	}
	else
	{
		cout << "Error updating Magician node! " << endl;
		system("pause");
		return false;
	}
	
	// delete dynamically allocated memory for the new booking node
	delete newNode;
	newNode = nullptr;
	
	return true;
}
