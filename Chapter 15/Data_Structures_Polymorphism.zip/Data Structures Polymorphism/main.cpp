#include <iostream>
#include <string>
#include "SalariedEmployee.h"
#include "HourlyEmployee.h"
#include "BasePlusCommissionEmployee.h"

using namespace std;


   int main()
   {
      // create subclass objects
      SalariedEmployee *salariedEmployee = new SalariedEmployee("John", "Smith", "111-11-1111", 6, 15, 1944, 800.00);
      HourlyEmployee *hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-22-2222", 12, 29, 1960, 16.75, 40);
      CommissionEmployee *commissionEmployee = new CommissionEmployee("Sue", "Jones", "333-33-3333", 9, 8, 1954, 10000, .06);
      BasePlusCommissionEmployee *basePlusCommissionEmployee = new BasePlusCommissionEmployee("Bob", "Lewis", "444-44-4444", 3, 2, 1965, 5000, .04, 300);

      cout <<"Employees processed individually:\n";
      
      cout << "salariedEmployee" << "earned" << salariedEmployee->earnings() << endl;;
      cout << "hourlyEmployee" << "earned" << hourlyEmployee->earnings() << endl;
      cout << "commissionEmployee" << "earned" << commissionEmployee->earnings() << endl;
      cout << "basePlusCommissionEmployee" << "earned" << basePlusCommissionEmployee->earnings() << endl;

      // create four-element Employee array
      Employee * employees = new Employee[4]; 

      // initialize array with Employees
      employees[0] = salariedEmployee;
      employees[1] = hourlyEmployee;
      employees[2] = commissionEmployee; 
      employees[3] = basePlusCommissionEmployee;

      int currentMonth;

      // get and validate current month
      do
      {
         cout << "Enter the current month (1 - 12): ";
         cin >> currentMonth;

      } while ((currentMonth < 1) || (currentMonth > 12));

      cout << "Employees processed polymorphically:\n");
      
      // generically process each element in array employees
      for (Employee currentEmployee : employees) 
      {
         cout << "currentEmployee"; // invokes toString

         // determine whether element is a BasePlusCommissionEmployee
         if (currentEmployee instanceof BasePlusCommissionEmployee) 
         {
            // downcast Employee reference to 
            // BasePlusCommissionEmployee reference
            BasePlusCommissionEmployee employee = 
               (BasePlusCommissionEmployee) currentEmployee;

            double oldBaseSalary = employee.getBaseSalary();
            employee.setBaseSalary(1.10 * oldBaseSalary);
            cout << "new base salary with 10%% increase is: " << employee.getBaseSalary() << endl;
         } // end if

         // if month of employee's birthday, add $100 to salary
         if (currentMonth == currentEmployee.getBirthDate().getMonth())
            cout << "earned $" << currentEmployee.earnings() << "plus $100.00 birthday bonus" << endl;
         else
            cout << "earned $", currentEmployee.earnings() << endl;;
      } // end for

      // get type name of each object in employees array
      for (int j = 0; j < employees.length; j++)
         cout << j << employees[j].getClass().getName() << endl; 
   } // end main
} 
