// This program uses two floating-point data types, float and double.
#include <iostream>
using namespace std;

int main()
{
	float distance = 1.496E8;         // in kilometers
	double mass = 1.989E30;           // in kilograms

	cout << "The Sun is " << distance << " kilometers away.\n";
	cout << "The Sun\'s mass is " << mass << " kilograms.\n";
	return 0;
}
