#include <iostream>
#include <string>
using namespace std;

int main()
{
	struct PayRoll
	{
		string name;
		int empNum;
	};
	
	PayRoll* payRollPtr = new PayRoll;
	payRollPtr->name = "John Doe";
	payRollPtr->empNum = 987;

}
