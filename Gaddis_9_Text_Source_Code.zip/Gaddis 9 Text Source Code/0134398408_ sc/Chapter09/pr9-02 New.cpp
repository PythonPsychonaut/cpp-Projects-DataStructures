// This program performs a binary search on an integer 
// array whose elements are in ascending order.
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

// Function prototype
int binarySearch(const int [], int, int);

const int SIZE = 200;

int main()
{
	// Create an array of ID numbers sorted in ascending order
	int IDnums[SIZE];
	for (int i=0; i<SIZE; i++)
		IDnums[i] = rand()*100 + 1;
	
	int index = rand()%200;
	cout << "The index is " << index << endl;	
	int empID = IDnums[rand()%200];
	cout << "Searching for " << empID << endl;
							  
	int results;        // Holds the search results

	// Search for the ID
	results = binarySearch(IDnums, SIZE, empID);
	
	// If binarySearch returned -1, the ID was not found
	if (results == -1)
		cout << "That number does not exist in the array.\n";
	else
	{  // Otherwise results contains the subscript of
	   // the specified employee ID in the array
		cout << "ID " << empID << " was found in element "
		     << results << " of the array.\n";
	}
	return 0;
}

/*****************************************************************
 *                         binarySearch                          *
 * This function performs a binary search on an integer array    *
 * with size elements whose values are stored in ascending       *
 * order. The array is searched for the number stored in the     *
 * value parameter. If the number is found, its array subscript  *
 * is returned. Otherwise, -1 is returned.                       *
 *****************************************************************/
int binarySearch(const int array[], int size, int value)
{
	int  first = 0,                     // First array element
	     last = size - 1,               // Last array element
	     middle,                        // Midpoint of search
	     position = -1;                 // Position of search value
	bool found = false;                 // Flag

	while (!found && first <= last)
	{
		middle = (first + last) / 2;    // Calculate midpoint
		if (array[middle] == value)     // If value is found at mid
		{
			found = true;
			position = middle;
		}
		else if (array[middle] > value) // If value is in lower half
			last = middle - 1;
		else
			first = middle + 1;         // If value is in upper half
	}
	return position;
}
