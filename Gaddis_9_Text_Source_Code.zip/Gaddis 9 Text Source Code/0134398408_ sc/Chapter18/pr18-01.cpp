// This program illustrates the IntStack class.
#include <iostream>
using namespace std;

class IntStack
{
   int * stackArray;
   int capacity;
   int top;
public:
   // Constructor 
   IntStack(int capacity);

   // Member functions
   void push(int value);
   void pop(int &value);
   bool isEmpty() const;

   // Stack Exceptions 
   class Overflow {};
   class Underflow {};
};
//************************************
// Constructor                       *
//************************************
IntStack::IntStack(int capacity)
{
   stackArray = new int[capacity];
   this->capacity = capacity;
   top = 0;
}

//***********************************
// Adds a value to the stack        *
//***********************************
void IntStack::push(int value)
{
   if (top == capacity) throw IntStack::Overflow();
   stackArray[top] = value;
   top++;
}

//****************************************
// Determines whether the stack is empty *
//****************************************
bool IntStack::isEmpty() const
{
   return top == 0;
}

//************************************************
// Removes a value from the stack and returns it *
//************************************************
void IntStack::pop(int &value)
{
   if (isEmpty()) throw IntStack::Underflow();
   top--;
   value = stackArray[top];
}

int main()
{
   IntStack  stack(5);
   int values[] = { 5, 10, 15, 20, 25 };
   int value;

   cout << "Pushing...\n";
   for (int k = 0; k < 5; k++)
   {
      cout << values[k] << "  ";
      stack.push(values[k]);
   }
   cout << "\nPopping...\n";
   while (!stack.isEmpty())
   {
      stack.pop(value);
      cout << value << "  ";
   }
   cout << endl;
   return 0;
}
