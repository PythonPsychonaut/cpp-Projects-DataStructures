#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
const int SIZE = 125000;
void selectionSort(int array[]);
void sortArray(int array[]);
void radixsort(int arr[]);
int getMax(int arr[]);
void countSort(int arr[], int exp);


int main()
{
	int nums[SIZE];
	for (int i=0; i< SIZE; i++)
		nums[i] = rand() % 100 +1;
	time_t start = time(0);
	cout << "Starting sort...@ " << start << endl;
//	selectionSort(nums);
//	sortArray(nums);

	radixsort(nums);


	time_t end = time(0);
	cout << "Sort ended...@ " << end << endl;
	cout << "Total time in computer seconds: " << end - start  << endl;
	system("pause");
		
	
	
}
void selectionSort(int array[])
{
	int startScan, minIndex, minValue;

	for (startScan = 0; startScan < (SIZE - 1); startScan++)
	{
		minIndex = startScan;
		minValue = array[startScan];
		for(int index = startScan + 1; index < SIZE; index++)
		{
			if (array[index] < minValue)
			{
				minValue = array[index];
				minIndex = index;
			}
      }
		array[minIndex] = array[startScan];
		array[startScan] = minValue;
	}
}
void sortArray(int array[])
{
	int  temp;
	bool madeAswap;

	do
	{
		madeAswap = false;
		for (int count = 0; count < (SIZE - 1); count++)
		{
			if (array[count] > array[count + 1])
			{
				temp = array[count];
				array[count] = array[count + 1];
				array[count + 1] = temp;
				madeAswap = true;
			}
		}
	} while (madeAswap);  // Loop again if a swap occurred on this pass.
}
int getMax(int arr[])
{
	int max = arr[0];
	for (int i = 1; i < SIZE; i++)
		if (arr[i] > max)
			max = arr[i];
	return max;
}

// Count sort of arr[].
void countSort(int arr[],int exp)
{
	// Count[i] array will be counting the number of array values having that 'i' digit at their (exp)th place.  
	int output[SIZE], i, count[10] = { 0 };

	// Count the number of times each digit occurred at (exp)th place in every input.
	for (i = 0; i < SIZE; i++)
		count[(arr[i] / exp) % 10]++;

	// Calculating their cumulative count.
	for (i = 1; i < 10; i++)
		count[i] += count[i - 1];

	// Inserting values according to the digit '(arr[i] / exp) % 10' fetched into count[(arr[i] / exp) % 10].
	for (i = SIZE - 1; i >= 0; i--)
	{
		output[count[(arr[i] / exp) % 10] - 1] = arr[i];
		count[(arr[i] / exp) % 10]--;
	}

	// Assigning the result to the arr pointer of main().
	for (i = 0; i < SIZE; i++)
		arr[i] = output[i];
}

// Sort arr[] of size n using Radix Sort.
void radixsort(int arr[])
{
	int exp, m;
	m = getMax(arr);

	// Calling countSort() for digit at (exp)th place in every input.
	for (exp = 1; m / exp > 0; exp *= 10)
		countSort(arr, exp);
}

